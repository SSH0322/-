package com.kori.battlecenter.engine

import com.kori.battlecenter.model.*

class BattleEngine {
    fun rank(states:Collection<MarketState>):BattleCandidate? =
        states.mapNotNull { s ->
            if(s.price<=0) return@mapNotNull null
            val momentum=when {
                s.change24h>=8 -> 12.0
                s.change24h>=4 -> 10.0
                s.change24h>=1.5 -> 8.0
                s.change24h>0 -> 5.0
                else -> 0.0
            }
            val book=when {
                s.bidAskRatio>=1.5 -> 10.0
                s.bidAskRatio>=1.2 -> 7.0
                s.bidAskRatio>=1.0 -> 4.0
                else -> 0.0
            }
            val penalty=if(s.change24h>25) 18.0 else 0.0
            val score=momentum+book-penalty
            if(score<12) null else BattleCandidate(
                s.code,score,s.price,s.price*1.02,s.price*0.99,
                listOf("24h ${"%.2f".format(s.change24h)}%","호가 매수/매도 ${"%.2f".format(s.bidAskRatio)}")
            )
        }.maxByOrNull { it.score }
}
