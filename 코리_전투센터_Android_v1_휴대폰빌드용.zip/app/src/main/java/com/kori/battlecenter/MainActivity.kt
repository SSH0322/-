package com.kori.battlecenter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.kori.battlecenter.data.UpbitClient
import com.kori.battlecenter.engine.BattleEngine
import com.kori.battlecenter.ui.MainScreen
import com.kori.battlecenter.model.MarketState
import kotlinx.coroutines.launch

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{
  var status by remember{mutableStateOf("OFFLINE")}
  var markets by remember{mutableStateOf(0)}
  var states by remember{mutableStateOf(listOf<MarketState>())}
  var candidate by remember{mutableStateOf<com.kori.battlecenter.model.BattleCandidate?>(null)}
  val scope=rememberCoroutineScope(); val engine=remember{BattleEngine()}
  val client=remember{UpbitClient({s->states=(states.filterNot{it.code==s.code}+s)},{status=it})}
  MaterialTheme{Surface{MainScreen(status,markets,states,candidate,
   onConnect={scope.launch{try{val m=client.loadMarkets();markets=m.size;client.connect(m)}catch(e:Exception){status="ERROR: ${e.message}"}}},
   onBattle={candidate=engine.rank(states)}
  )}}
 }}
}
