package com.kori.battlecenter.data

import com.kori.battlecenter.model.MarketState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

class UpbitClient(private val onMarket:(MarketState)->Unit, private val onStatus:(String)->Unit) {
    private val client=OkHttpClient.Builder().pingInterval(20,TimeUnit.SECONDS).build()
    private var socket:WebSocket?=null
    private val states=HashMap<String,MarketState>()

    suspend fun loadMarkets():List<String> = withContext(Dispatchers.IO) {
        val req=Request.Builder().url("https://api.upbit.com/v1/market/all?is_details=false").build()
        client.newCall(req).execute().use { r ->
            if(!r.isSuccessful) error("HTTP ${r.code}")
            val a=JSONArray(r.body?.string()?:"[]")
            buildList { for(i in 0 until a.length()) {
                val m=a.getJSONObject(i).getString("market")
                if(m.startsWith("KRW-")) add(m)
            }}
        }
    }

    fun connect(markets:List<String>) {
        socket=client.newWebSocket(Request.Builder().url("wss://api.upbit.com/websocket/v1").build(),
            object:WebSocketListener(){
                override fun onOpen(ws:WebSocket,response:Response){
                    onStatus("LIVE")
                    val msg=JSONArray()
                    msg.put(JSONObject().put("ticket",UUID.randomUUID().toString()))
                    msg.put(JSONObject().put("type","ticker").put("codes",JSONArray(markets)).put("is_only_realtime",true))
                    msg.put(JSONObject().put("type","trade").put("codes",JSONArray(markets)).put("is_only_realtime",true))
                    msg.put(JSONObject().put("type","orderbook").put("codes",JSONArray(markets)).put("is_only_realtime",true))
                    msg.put(JSONObject().put("format","SIMPLE"))
                    ws.send(msg.toString())
                }
                override fun onMessage(ws:WebSocket,text:String){ handle(JSONObject(text)) }
                override fun onFailure(ws:WebSocket,t:Throwable,response:Response?){ onStatus("ERROR: ${t.message}") }
                override fun onClosed(ws:WebSocket,code:Int,reason:String){ onStatus("CLOSED") }
            })
    }

    private fun handle(o:JSONObject) {
        val type=o.optString("ty"); val code=o.optString("cd"); if(code.isBlank()) return
        val old=states[code]?:MarketState(code,0.0,0.0)
        val u=when(type) {
            "ticker" -> old.copy(price=o.optDouble("tp",old.price),change24h=o.optDouble("pcp",0.0))
            "trade" -> old.copy(price=o.optDouble("tp",old.price))
            "orderbook" -> {
                val bid=o.optDouble("tbs",0.0); val ask=o.optDouble("tas",0.0)
                old.copy(bidAskRatio=if(ask>0) bid/ask else 1.0)
            }
            else -> old
        }.copy(updatedAt=System.currentTimeMillis())
        states[code]=u; onMarket(u)
    }
}
