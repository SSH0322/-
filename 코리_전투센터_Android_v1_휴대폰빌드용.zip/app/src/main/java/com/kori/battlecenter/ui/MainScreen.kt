package com.kori.battlecenter.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.kori.battlecenter.model.*

@Composable
fun MainScreen(status:String,markets:Int,states:List<MarketState>,candidate:BattleCandidate?,onConnect:()->Unit,onBattle:()->Unit){
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Text("⚔️ 코리 전투센터",style=MaterialTheme.typography.headlineMedium)
        Text("업비트: $status | KRW 감시: $markets")
        Spacer(Modifier.height(12.dp))
        Button(onClick=onConnect,Modifier.fillMaxWidth()){Text("실시간 연결")}
        Spacer(Modifier.height(8.dp))
        Button(onClick=onBattle,Modifier.fillMaxWidth()){Text("⚔️ 전투개시")}
        Spacer(Modifier.height(16.dp))
        candidate?.let { c ->
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){
                Text("최종 후보",style=MaterialTheme.typography.titleLarge)
                Text(c.code,style=MaterialTheme.typography.headlineSmall)
                Text("현재가: ${c.price}")
                Text("24시간 내 목표(+2%): ${c.target}")
                Text("방어 기준(-1%): ${c.defense}")
                Text("조건 점수: ${"%.1f".format(c.score)}")
                c.reasons.forEach{Text("• $it")}
            }}
        } ?: Text("전투개시를 누르면 현재 관측 조건을 분석합니다.")
        Spacer(Modifier.height(12.dp))
        Text("실시간 수신")
        LazyColumn{items(states.sortedByDescending{it.change24h}.take(20)){s->Text("${s.code}  ${s.price}  ${"%.2f".format(s.change24h)}%")}}
    }
}
