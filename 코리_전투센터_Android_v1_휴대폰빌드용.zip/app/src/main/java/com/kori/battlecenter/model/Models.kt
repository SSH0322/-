package com.kori.battlecenter.model

data class MarketState(
    val code:String, val price:Double, val change24h:Double,
    val tradeValue24h:Double=0.0, val bidAskRatio:Double=1.0,
    val updatedAt:Long=System.currentTimeMillis()
)
data class BattleCandidate(
    val code:String, val score:Double, val price:Double,
    val target:Double, val defense:Double, val reasons:List<String>
)
