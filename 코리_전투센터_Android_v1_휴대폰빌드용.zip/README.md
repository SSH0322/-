# 코리 전투센터 Android v1 - 휴대폰 빌드용

이 프로젝트는 PC 없이 GitHub Actions에서 APK를 빌드할 수 있도록 workflow를 포함합니다.

## 휴대폰 빌드
1. GitHub에서 새 repository를 만듭니다.
2. 이 폴더의 파일 전체를 repository에 업로드합니다.
3. GitHub의 Actions → Build APK → Run workflow를 누릅니다.
4. 빌드가 끝나면 Actions 실행 결과의 Artifacts에서 `kori-battle-center-debug`를 내려받습니다.
5. ZIP을 풀고 `app-debug.apk`를 휴대폰에 설치합니다.

## 현재 기능
- Upbit KRW 전체 시장 목록
- Public WebSocket ticker/trade/orderbook
- 전투개시 단일 후보 선정
- +2% 목표 / -1% 방어 기준 표시
- 자동 주문 없음 / API Key 없음

## 주의
v1의 점수는 실제 확률이 아닙니다. 최종 목표를 위해서는 1/5/15분 OHLCV, 거래대금 변화, 체결강도, 돌파/눌림 특징과 과거 24시간 +2% 도달 여부를 이용한 백테스트가 추가되어야 합니다.
